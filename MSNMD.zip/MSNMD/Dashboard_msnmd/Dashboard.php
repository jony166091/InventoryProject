<?php
    //start the session.
    $user = $_SESSION['user'];
?>
<!DOCTYPE html>
<!-- saved from url=(0060)https://www.wrraptheme.com/templates/compass/html/index.html -->
<html class="no-js chrome" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="description" content="Responsive Bootstrap 4 and web Application ui kit.">

    <title>MSDN</title>
    <link rel="icon" href="" type="image/x-icon"> <!-- Favicon-->

    <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-jvectormap-2.0.3.min.css">
    <link rel="stylesheet" href="css/morris.min.css">
    <!-- Custom Css -->
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/color_skins.css">
    <script src="https://use.fontawesome.com/0c7a3095b5.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
S

    <style type="text/css">
    .jqstooltip
     { 
        position: absolute;
        left: 0px;top: 0px;visibility: hidden;
        background: rgb(0, 0, 0) transparent;
        background-color: rgba(0,0,0,0.6);
        filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);
        -ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";
        color: white;
        font: 10px arial, san serif;
        text-align: left;
        white-space: nowrap;
        padding: 5px;
        border: 1px solid white;
        box-sizing: content-box;
        z-index: 10000;
      }
      .jqsfield 
      { 
          color: white;
          font: 10px arial, san serif;
          text-align: left;
      }
    </style>

    <script charset="utf-8" src="js/twk-chunk-2d0d2b7c.js"></script>
    <script charset="utf-8" src="js/twk-chunk-2d224aff.js"></script>
    <script charset="utf-8" src="js/twk-chunk-48f46bef.js"></script>
    <script charset="utf-8" src="js/twk-chunk-4fe9d5dd.js"></script>
    <script charset="utf-8" src="js/twk-chunk-2d0b9454.js"></script>
    <script charset="utf-8" src="js/twk-chunk-f163fcd0.js"></script>
    <script charset="utf-8" src="js/twk-chunk-35f53b3a.js"></script>
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>


    <style type="text/css">
    #ql4ka8c628v1f7tcld3d 
    {
        outline:none !important;
        visibility:visible !important;
        resize:none !important;
        box-shadow:none !important;
        overflow:visible !important;
        background:none !important;
        opacity:1 !important;
        filter:alpha(opacity=100) !important;
        -ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity 1}) !important;
        -mz-opacity:1 !important;
        -khtml-opacity:1 !important;
        top:auto !important;
        right:0px !important;
        bottom:0px !important;
        left:auto !important;
        position:fixed !important;
        border:0 !important;
        min-height:0px  !important;
        min-width:0px  !important;
        max-height:none  !important;
        max-width:none  !important;
        padding:0px !important;
        margin:0px !important;
        -moz-transition-property:none !important;
        -webkit-transition-property:none !important;
        -o-transition-property:none !important;
        transition-property:none !important;
        transform:none !important;
        -webkit-transform:none !important;
        -ms-transform:none !important;
        width:auto !important;
        height:auto  !important;
        display:block !important;
        z-index:2000000000 !important;
        background-color:transparent !important;
        cursor:none !important;
        float:none !important;
        border-radius:unset !important;
        pointer-events:auto !important;
    }
    </style>


    <script src="js/emojione.min.js" type="text/javascript" async="" defer=""></script>
    <script src="js/emojione.min.js" type="text/javascript" async="" defer=""></script>
    <style type="text/css">
          @keyframes tawkMaxOpen
            {0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}

          @-moz-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}

          @-webkit-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}

          #q65uo0h09r5g1f7tcldcv.open{animation : tawkMaxOpen .25s ease!important;}

          @keyframes tawkMaxClose{from{opacity: 1;transform:translate(0, 0px);;}to{opacity: 0;transform:translate(0, 30px);;}}

          @-moz-keyframes tawkMaxClose{from{opacity: 1;transform:translate(0, 0px);;}to{opacity: 0;transform:translate(0, 30px);;}}

          @-webkit-keyframes tawkMaxClose{from{opacity: 1;transform:translate(0, 0px);;}to{opacity: 0;transform:translate(0, 30px);;}}
          #q65uo0h09r5g1f7tcldcv.closed{animation: tawkMaxClose .25s ease!important}

    </style>

</head>

<!-- Body start here -->

<body class="theme-cyan" style="overflow: auto;">

<!-- Page Loader -->
<div class="page-loader-wrapper" style="display: none;">
    <div class="loader">
        <div class="m-t-30"><img class="zmdi-hc-spin" src="icon/logo.svg" width="48" height="48" alt="Compass"></div>
        <p>Please wait...</p>
    </div>
</div>
<!-- Overlay For Sidebars -->
<div class="overlay"></div>

<!-- Top Bar -->

<nav class="navbar">
    <div class="col-12">        
        <div class="navbar-header">
            <a href="javascript:void(0);" class="bars" style="display: none;"></a>
            <a class="navbar-brand" href=""><img src="icon/logo.svg" width="40" alt="MSNMD"><span class="m-l-10">MSNMD</span></a>
        </div>
        <ul class="nav navbar-nav navbar-left">
            <li><a href="javascript:void(0);" class="ls-toggle-btn" data-close="true"><i class="zmdi zmdi-swap"></i></a></li>            
            <li class="hidden-sm-down">
               <!-- <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <span class="input-group-addon">
                        <i class="zmdi zmdi-search"></i>
                    </span>
                </div>-->
            </li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <!--<li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button"><i class="zmdi zmdi-notifications"></i>
                <div class="notify"><span class="heartbit"></span><span class="point"></span></div>
                </a>

                Notification 
                <ul class="dropdown-menu dropdown-menu-right slideDown">
                    <li class="header">NOTIFICATIONS</li>
                    <li class="body">
                        <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 254px;"><ul class="menu list-unstyled" style="overflow: hidden; width: auto; height: 254px;">
                            <li> <a href="javascript:void(0);">
                                <div class="icon-circle bg-blue"><i class="zmdi zmdi-account"></i></div>
                                <div class="menu-info">
                                    <h4>8 New Members joined</h4>
                                    <p><i class="zmdi zmdi-time"></i> 14 mins ago </p>
                                </div>
                                </a> </li>
                            <li> <a href="javascript:void(0);">
                                <div class="icon-circle bg-amber"><i class="zmdi zmdi-shopping-cart"></i></div>
                                <div class="menu-info">
                                    <h4>4 Sales made</h4>
                                    <p> <i class="zmdi zmdi-time"></i> 22 mins ago </p>
                                </div>
                                </a> </li>
                            <li> <a href="javascript:void(0);">
                                <div class="icon-circle bg-red"><i class="zmdi zmdi-delete"></i></div>
                                <div class="menu-info">
                                    <h4><b>Nancy Doe</b> Deleted account</h4>
                                    <p> <i class="zmdi zmdi-time"></i> 3 hours ago </p>
                                </div>
                                </a> </li>
                            <li> <a href="javascript:void(0);">
                                <div class="icon-circle bg-green"><i class="zmdi zmdi-edit"></i></div>
                                <div class="menu-info">
                                    <h4><b>Nancy</b> Changed name</h4>
                                    <p> <i class="zmdi zmdi-time"></i> 2 hours ago </p>
                                </div>
                                </a> </li>
                            <li> <a href="javascript:void(0);">
                                <div class="icon-circle bg-grey"><i class="zmdi zmdi-comment-text"></i></div>
                                <div class="menu-info">
                                    <h4><b>John</b> Commented your post</h4>
                                    <p> <i class="zmdi zmdi-time"></i> 4 hours ago </p>
                                </div>
                                </a> </li>
                            <li> <a href="javascript:void(0);">
                                <div class="icon-circle bg-purple"><i class="zmdi zmdi-refresh"></i></div>
                                <div class="menu-info">
                                    <h4><b>John</b> Updated status</h4>
                                    <p> <i class="zmdi zmdi-time"></i> 3 hours ago </p>
                                </div>
                                </a> </li>
                            <li> <a href="javascript:void(0);">
                                <div class="icon-circle bg-light-blue"><i class="zmdi zmdi-settings"></i></div>
                                <div class="menu-info">
                                    <h4>Settings Updated</h4>
                                    <p> <i class="zmdi zmdi-time"></i> Yesterday </p>
                                </div>
                                </a>
                            </li>
                        </ul>
                        <div class="slimScrollBar" style="background: rgba(0, 0, 0, 0.2); width: 3px; position: absolute; top: 0px; opacity: 0.4; display: block; border-radius: 3px; z-index: 99; right: 1px;">
                          
                        </div>
                        <div class="slimScrollRail" style="width: 3px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 0px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;">
                          
                        </div>
                      </div>
                    </li>
                    <li class="footer"> <a href="javascript:void(0);">View All Notifications</a> </li>
                </ul>
            </li>
            <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button"><i class="zmdi zmdi-flag"></i>
                <div class="notify"><span class="heartbit"></span><span class="point"></span></div>
                </a>
                <ul class="dropdown-menu dropdown-menu-right slideDown">
                    <li class="header">TASKS</li>
                    <li class="body">
                        <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 254px;"><ul class="menu tasks list-unstyled" style="overflow: hidden; width: auto; height: 254px;">
                            <li> <a href="javascript:void(0);">
                                <div class="progress-container progress-primary">
                                    <span class="progress-badge">Footer display issue</span>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                            <span class="progress-value">86%</span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </li>
                            <li> <a href="javascript:void(0);">
                                <div class="progress-container progress-info">
                                    <span class="progress-badge">Answer GitHub questions</span>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100" style="width: 35%;">
                                            <span class="progress-value">35%</span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </li>
                            <li> <a href="javascript:void(0);">
                                <div class="progress-container progress-success">
                                    <span class="progress-badge">Solve transition issue</span>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="72" aria-valuemin="0" aria-valuemax="100" style="width: 72%;">
                                            <span class="progress-value">72%</span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </li>
                            <li><a href="javascript:void(0);">
                                <div class="progress-container">
                                    <span class="progress-badge"> Create new dashboard</span>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 45%;">
                                            <span class="progress-value">45%</span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </li>
                            <li> <a href="javascript:void(0);">
                                <div class="progress-container progress-warning">
                                    <span class="progress-badge">Panding Project</span>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="29" aria-valuemin="0" aria-valuemax="100" style="width: 29%;">
                                            <span class="progress-value">29%</span>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </li>
                        </ul><div class="slimScrollBar" style="background: rgba(0, 0, 0, 0.2); width: 3px; position: absolute; top: 0px; opacity: 0.4; display: block; border-radius: 3px; z-index: 99; right: 1px;"></div><div class="slimScrollRail" style="width: 3px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 0px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
                    </li>
                    <li class="footer"><a href="javascript:void(0);">View All</a></li>
                </ul>
            </li>-->
            <li>
                <a href="javascript:void(0);" class="fullscreen hidden-sm-down" data-provide="fullscreen" data-close="true"><i class="zmdi zmdi-fullscreen"></i>
            </li>
            <li><a href="/database/logout.php" class="mega-menu" data-close="true"><i class="fa fa-power-off"></i>Log-out</a></li> <!--zmdi zmdi-power-->
            <li class=""><a href="javascript:void(0);" class="js-right-sidebar" data-close="true"><i class="zmdi zmdi-settings zmdi-hc-spin"></i></a></li>
        </ul>
    </div>
</nav>

<!-- Left Sidebar -->
<aside id="leftsidebar" class="sidebar">
    <div class="menu">
        <ul class="list">
            <li>
                
            </li>
            <li class="active open"> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-home"></i><span>ড্যাশবোর্ড</span></a>
                <!--<ul class="ml-menu" style="display: none;">
                    <li class="active"><a href="https://www.wrraptheme.com/templates/compass/html/index.html" class="toggled waves-effect waves-block">Main</a> </li>
                    <li><a href="" class=" waves-effect waves-block">RTL</a></li>
                    <li><a href="" class=" waves-effect waves-block">Horizontal</a></li>
                    <li><a href="" class=" waves-effect waves-block">Ecommerce</a></li>
                    <li><a href="" class=" waves-effect waves-block">Blog</a></li>
                </ul>-->
            </li>
            <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-apps"></i><span>ব্যক্তি </span> </a>
                <ul class="ml-menu" style="display: none;">
                    <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-apps"></i><span>ক্লাইন্ট </span> </a>
                        <ul class="ml-menu" style="display: none;">
                            <li><a href="" class=" waves-effect waves-block">নতুন কাষ্টমার জুক্ত</a></li>
                            <li><a href="" class=" waves-effect waves-block">কাষ্টমার তালিকা</a></li>
                        </ul>    
                    </li>
                    <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-apps"></i><span>সাপ্লাইয়ার </span> </a>
                        <ul class="ml-menu" style="display: none;">
                             
                             <li><a href="" class=" waves-effect waves-block">সাপ্লাইয়ার যুক্ত</a></li>
                             <li><a href="" class=" waves-effect waves-block">সাপ্লাইয়ার তালিকা</a></li>
                             
                        </ul>    
                    </li>

                    <!--<li><a href="" class=" waves-effect waves-block">Chat</a></li>
                    <li><a href="" class=" waves-effect waves-block">Calendar</a></li>
					<li><a href="" class=" waves-effect waves-block">File Manager</a></li>
                    <li><a href="" class=" waves-effect waves-block">Contact list</a></li>
                    <li><a href="" class=" waves-effect waves-block">Blog</a></li> -->
                </ul>
            </li>            
            <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-swap-alt"></i><span>আকাউন্ট</span> </a>
                <ul class="ml-menu" style="display: none;">
                    <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-apps"></i><span>জমা </span> </a>
                        <ul class="ml-menu" style="display: none;">
                            <li><a href="" class=" waves-effect waves-block">নতুন জমা</a></li>
                            <li><a href="" class=" waves-effect waves-block">জমার রিপোর্ট</a></li>
                        </ul>    
                    </li>
                    <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-apps"></i><span>খরচ </span> </a>
                        <ul class="ml-menu" style="display: none;">
                             
                             <li><a href="" class=" waves-effect waves-block">দৈনিক খরচ</a></li>
                             <li><a href="" class=" waves-effect waves-block">খরচের তালিকা</a></li>
                             
                        </ul>    
                    </li>
                </ul>
            </li>
            <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-assignment"></i><span>প্রোডাক্ট</span> </a>
                <ul class="ml-menu" style="display: none;">
                    <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-apps"></i><span>প্রোডাক্ট </span> </a>
                        <ul class="ml-menu" style="display: none;">
                            <li><a href="" class=" waves-effect waves-block">প্রোডাক্ট যুক্ত করুন</a></li>
                            <li><a href="" class=" waves-effect waves-block">প্রোডাক্ট তালিকা</a></li>
                        </ul>    
                    </li>
                    <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-apps"></i><span>ক্রয়
                     </span> </a>
                        <ul class="ml-menu" style="display: none;">
                             
                             <li><a href="" class=" waves-effect waves-block">দৈনিক খরচ</a></li>
                             <li><a href="" class=" waves-effect waves-block">খরচের তালিকা</a></li>
                             
                        </ul>    
                    </li>
                    <li><a href="" class=" waves-effect waves-block">স্টক</a></li>
                </ul>
            </li>
            <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-grid"></i><span>দোকান</span> </a>
                <ul class="ml-menu">                        
                    <li> <a href="" class=" waves-effect waves-block">দোকান - ১</a> </li>
                    <li> <a href="" class=" waves-effect waves-block">দোকান - ২</a> </li>
                </ul>
            </li>            
            <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-chart"></i><span>Charts</span> </a>
                <ul class="ml-menu">
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/morris.html" class=" waves-effect waves-block">Morris</a> </li>
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/flot.html" class=" waves-effect waves-block">Flot</a> </li>
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/chartjs.html" class=" waves-effect waves-block">ChartJS</a> </li>
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/sparkline.html" class=" waves-effect waves-block">Sparkline</a> </li>
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/jquery-knob.html" class=" waves-effect waves-block">Jquery Knob</a> </li>
                </ul>
            </li>
            <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-shopping-cart"></i><span>Ecommerce</span> </a>
                <ul class="ml-menu">
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/ec-dashboard.html" class=" waves-effect waves-block">Dashboard</a></li>
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/ec-product.html" class=" waves-effect waves-block">Product</a></li>
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/ec-product-List.html" class=" waves-effect waves-block">Product List</a></li>
                    <li> <a href="https://www.wrraptheme.com/templates/compass/html/ec-product-detail.html" class=" waves-effect waves-block">Product detail</a></li>
                </ul>
            </li>
            <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-delicious"></i><span>Widgets</span> </a>
                <ul class="ml-menu">
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/widgets-app.html" class=" waves-effect waves-block">Apps Widgets</a></li>
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/widgets-data.html" class=" waves-effect waves-block">Data Widgets</a></li>
                </ul>
            </li>
            <li> <a href="javascript:void(0);" class="menu-toggle waves-effect waves-block"><i class="zmdi zmdi-lock"></i><span>Authentication</span> </a>
                <ul class="ml-menu">
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/sign-in.html" class=" waves-effect waves-block">Sign In</a> </li>
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/sign-up.html" class=" waves-effect waves-block">Sign Up</a> </li>
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/forgot-password.html" class=" waves-effect waves-block">Forgot Password</a> </li>
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/404.html" class=" waves-effect waves-block">Page 404</a> </li>
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/500.html" class=" waves-effect waves-block">Page 500</a> </li>
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/page-offline.html" class=" waves-effect waves-block">Page Offline</a> </li>
                    <li><a href="https://www.wrraptheme.com/templates/compass/html/locked.html" class=" waves-effect waves-block">Locked Screen</a> </li>
                </ul>
            </li>
            
            
            <!--<li class="header">Extra</li>
            <li>
                <div class="progress-container progress-primary m-t-10">
                    <span class="progress-badge">Traffic this Month</span>
                    <div class="progress">
                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="67" aria-valuemin="0" aria-valuemax="100" style="width: 67%;">
                            <span class="progress-value">67%</span>
                        </div>
                    </div>
                </div>
                <div class="progress-container progress-info">
                    <span class="progress-badge">Server Load</span>
                    <div class="progress">
                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                            <span class="progress-value">86%</span>
                        </div>
                    </div>
                </div>
            </li>-->
        </ul>
    </div>
</aside>

<!-- Right Sidebar -->
<aside id="rightsidebar" class="right-sidebar">
    <ul class="nav nav-tabs">
        <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="https://www.wrraptheme.com/templates/compass/html/index.html#setting"><i class="zmdi zmdi-settings zmdi-hc-spin"></i></a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active slideRight" id="setting">
                <div class="card">
                    <h6>Skins</h6>
                    <ul class="choose-skin list-unstyled">
                        <li data-theme="purple">
                            <div class="purple"></div>
                        </li>                   
                        <li data-theme="blue">
                            <div class="blue"></div>
                        </li>
                        <li data-theme="cyan" class="active">
                            <div class="cyan"></div>                    
                        </li>
                        <li data-theme="green">
                            <div class="green"></div>
                        </li>
                        <li data-theme="orange">
                            <div class="orange"></div>
                        </li>
                        <li data-theme="blush">
                            <div class="blush"></div>                    
                        </li>
                    </ul>                    
                </div>
                <div class="card">
                    <h6>Left Menu</h6>
                    <ul class="list-unstyled theme-light-dark">
                        <li>
                            <div class="t-light btn btn-default btn-simple btn-round">Light</div>
                        </li>
                        <li>
                            <div class="t-dark btn btn-default btn-round">Dark</div>
                        </li>
                    </ul>
                </div>              
        <div class="tab-pane right_chat pullUp" id="chat">
                <div class="card">
                    <div class="search">                        
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-addon">
                                <i class="zmdi zmdi-search"></i>
                            </span>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</aside>

<!-- Main Content -->
<section class="content home">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>
                <strong class="text-muted" >ওয়েলকাম টু এম.এস. নিউ মা ডায়িং</strong>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">                
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="Dashboard.php"><i class="zmdi zmdi-home"></i>MSNMD</a></li>
                    <li class="breadcrumb-item active">Dashboard 1</li>
                </ul>                
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="card widget_2">
            <ul class="row clearfix list-unstyled m-b-0">
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">আজকের জমা</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">20</h2>
                                <small class="info">of 1Tb</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-amber" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 45%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">আজকের খরচ</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">12%</h2>
                                <small class="info">of 100</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-blue" role="progressbar" aria-valuenow="38" aria-valuemin="0" aria-valuemax="100" style="width: 38%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">আজকের অবশিষ্ট</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">39</h2>
                                <small class="info">of 100</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-parpl" role="progressbar" aria-valuenow="39" aria-valuemin="0" aria-valuemax="100" style="width: 39%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <!--<li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">Domians</h5>
                                <p class="text-small">Total registered Domain</p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">8</h2>
                                <small class="info">of 10</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-turquoise" role="progressbar" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100" style="width: 89%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>-->
                
            </ul>
        </div>
        <div class="card widget_2">
            <ul class="row clearfix list-unstyled m-b-0">
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">চলতি মাসের জমা</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">20</h2>
                                <small class="info">of 1Tb</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-amber" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 45%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">চলতি মাসের খরচ</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">12%</h2>
                                <small class="info">of 100</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-blue" role="progressbar" aria-valuenow="38" aria-valuemin="0" aria-valuemax="100" style="width: 38%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">চলতি মাসের অবশিষ্ট</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">39</h2>
                                <small class="info">of 100</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-parpl" role="progressbar" aria-valuenow="39" aria-valuemin="0" aria-valuemax="100" style="width: 39%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">Domians</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">8</h2>
                                <small class="info">of 10</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-turquoise" role="progressbar" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100" style="width: 89%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                
            </ul>
        </div>

        <div class="card widget_2">
            <ul class="row clearfix list-unstyled m-b-0">
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">সর্বমোট জমা</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">20</h2>
                                <small class="info">of 1Tb</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-amber" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 45%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">সর্বমোট খরচ</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">12%</h2>
                                <small class="info">of 100</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-blue" role="progressbar" aria-valuenow="38" aria-valuemin="0" aria-valuemax="100" style="width: 38%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">সর্বমোট অবশিষ্ট</h5>
                                <p class="text-small">সর্বমোট অবশিষ্ট</p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">39</h2>
                                <small class="info">of 100</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-parpl" role="progressbar" aria-valuenow="39" aria-valuemin="0" aria-valuemax="100" style="width: 39%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="col-lg-3 col-md-6 col-sm-12">
                    <div class="body">
                        <div class="row">
                            <div class="col-7">
                                <h5 class="m-t-0">Domians</h5>
                                <p class="text-small"></p>
                            </div>
                            <div class="col-5 text-right">
                                <h2 class="">8</h2>
                                <small class="info">of 10</small>
                            </div>
                            <div class="col-12">
                                <div class="progress m-t-20">
                                <div class="progress-bar l-turquoise" role="progressbar" aria-valuenow="89" aria-valuemin="0" aria-valuemax="100" style="width: 89%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                
            </ul>
        </div>

        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Sales</strong> Report</h2>
                        <ul class="header-dropdown">
                            <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-more"></i> </a>
                                <ul class="dropdown-menu dropdown-menu-right slideUp float-right">
                                    <li><a href="javascript:void(0);">Edit</a></li>
                                    <li><a href="javascript:void(0);">Delete</a></li>
                                    <li><a href="javascript:void(0);">Report</a></li>
                                </ul>
                            </li>
                            <li class="remove">
                                <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="body">
                        <!--<div class="row text-center">
                            <div class="col-sm-3 col-6">
                                <h4 class="m-t-0">$ 106 <i class="zmdi zmdi-trending-up col-green"></i></h4>
                                <p class="text-muted"> Today's Sales</p>
                            </div>
                            <div class="col-sm-3 col-6">
                                <h4 class="m-t-0">$ 907 <i class="zmdi zmdi-trending-down col-red"></i></h4>
                                <p class="text-muted">This Week's Sales</p>
                            </div>
                            <div class="col-sm-3 col-6">
                                <h4 class="m-t-0">$ 4210 <i class="zmdi zmdi-trending-up col-green"></i></h4>
                                <p class="text-muted">This Month's Sales</p>
                            </div>
                            <div class="col-sm-3 col-6">
                                <h4 class="m-t-0">$ 67,000 <i class="zmdi zmdi-trending-up col-green"></i></h4>
                                <p class="text-muted">This Year's Sales</p>
                            </div>
                        </div> -->
                        <div id="area_chart" class="graph" style="position: relative; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"><svg height="342" version="1.1" width="955" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="overflow: hidden; position: relative;"><desc style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Created with Raphaël 2.1.2</desc><defs style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></defs><text x="32.859375" y="303" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">0</tspan></text><path fill="none" stroke="#e0e0e0" d="M45.359375,303.5H930" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="32.859375" y="233.5" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">50</tspan></text><path fill="none" stroke="#e0e0e0" d="M45.359375,233.5H930" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="32.859375" y="164" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">100</tspan></text><path fill="none" stroke="#e0e0e0" d="M45.359375,164.5H930" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="32.859375" y="94.50000000000003" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="4.000000000000028" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">150</tspan></text><path fill="none" stroke="#e0e0e0" d="M45.359375,94.5H930" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="32.859375" y="25" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">200</tspan></text><path fill="none" stroke="#e0e0e0" d="M45.359375,25.5H930" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="930.0000000000001" y="315.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2017</tspan></text><text x="782.2908445483578" y="315.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2016</tspan></text><text x="634.9852660241788" y="315.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2015</tspan></text><text x="487.67968750000006" y="315.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2014</tspan></text><text x="340.3741089758212" y="315.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2013</tspan></text><text x="192.66495352417886" y="315.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2012</tspan></text><text x="45.359375" y="315.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2011</tspan></text><path fill="#f6e2ae" stroke="none" d="M45.359375,289.1C82.1857696310447,282.15000000000003,155.83855889313415,274.3134233926129,192.66495352417886,261.3C229.59224238708944,248.25092339261286,303.4468201129106,187.45981532147746,340.3741089758212,184.85000000000002C377.2005036068659,182.24731532147746,450.85329286895535,230.89374999999998,487.67968750000006,240.45C524.5060821310448,250.00625,598.1588713931342,275.2,634.9852660241788,261.3C671.8116606552236,247.4,745.464449917313,130.98512311901504,782.2908445483578,129.25C819.2181334112684,127.51012311901505,893.0727111370895,217.8625,930.0000000000001,247.4L930.0000000000001,303L45.359375,303Z" fill-opacity="0.8" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 0.8;"></path><path fill="none" stroke="#f7cf68" d="M45.359375,289.1C82.1857696310447,282.15000000000003,155.83855889313415,274.3134233926129,192.66495352417886,261.3C229.59224238708944,248.25092339261286,303.4468201129106,187.45981532147746,340.3741089758212,184.85000000000002C377.2005036068659,182.24731532147746,450.85329286895535,230.89374999999998,487.67968750000006,240.45C524.5060821310448,250.00625,598.1588713931342,275.2,634.9852660241788,261.3C671.8116606552236,247.4,745.464449917313,130.98512311901504,782.2908445483578,129.25C819.2181334112684,127.51012311901505,893.0727111370895,217.8625,930.0000000000001,247.4" stroke-width="0" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><circle cx="45.359375" cy="289.1" r="0" fill="#f7cf68" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="192.66495352417886" cy="261.3" r="0" fill="#f7cf68" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="340.3741089758212" cy="184.85000000000002" r="0" fill="#f7cf68" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="487.67968750000006" cy="240.45" r="0" fill="#f7cf68" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="634.9852660241788" cy="261.3" r="0" fill="#f7cf68" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="782.2908445483578" cy="129.25" r="0" fill="#f7cf68" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="930.0000000000001" cy="247.4" r="0" fill="#f7cf68" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><path fill="#7a7a7a" stroke="none" d="M45.359375,303C82.1857696310447,279.37,155.83855889313415,217.15561559507526,192.66495352417886,208.48000000000002C229.59224238708944,199.78061559507526,303.4468201129106,223.75668946648426,340.3741089758212,233.5C377.2005036068659,243.21668946648427,450.85329286895535,283.1925,487.67968750000006,286.32C524.5060821310448,289.4475,598.1588713931342,270.335,634.9852660241788,258.52C671.8116606552236,246.70499999999998,745.464449917313,187.9827291381669,782.2908445483578,191.8C819.2181334112684,195.6277291381669,893.0727111370895,264.77500000000003,930.0000000000001,289.1L930.0000000000001,303L45.359375,303Z" fill-opacity="0.8" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 0.8;"></path><path fill="none" stroke="#666666" d="M45.359375,303C82.1857696310447,279.37,155.83855889313415,217.15561559507526,192.66495352417886,208.48000000000002C229.59224238708944,199.78061559507526,303.4468201129106,223.75668946648426,340.3741089758212,233.5C377.2005036068659,243.21668946648427,450.85329286895535,283.1925,487.67968750000006,286.32C524.5060821310448,289.4475,598.1588713931342,270.335,634.9852660241788,258.52C671.8116606552236,246.70499999999998,745.464449917313,187.9827291381669,782.2908445483578,191.8C819.2181334112684,195.6277291381669,893.0727111370895,264.77500000000003,930.0000000000001,289.1" stroke-width="0" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><circle cx="45.359375" cy="303" r="0" fill="#666666" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="192.66495352417886" cy="208.48000000000002" r="0" fill="#666666" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="340.3741089758212" cy="233.5" r="0" fill="#666666" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="487.67968750000006" cy="286.32" r="0" fill="#666666" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="634.9852660241788" cy="258.52" r="0" fill="#666666" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="782.2908445483578" cy="191.8" r="0" fill="#666666" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="930.0000000000001" cy="289.1" r="0" fill="#666666" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><path fill="#d0c4e5" stroke="none" d="M45.359375,303C82.1857696310447,301.2625,155.83855889313415,300.0407831737346,192.66495352417886,296.05C229.59224238708944,292.0482831737346,303.4468201129106,275.0317168262654,340.3741089758212,271.03C377.2005036068659,267.0392168262654,450.85329286895535,277.11125,487.67968750000006,264.08C524.5060821310448,251.04874999999998,598.1588713931342,168.865,634.9852660241788,166.78C671.8116606552236,164.695,745.464449917313,234.90711354309167,782.2908445483578,247.4C819.2181334112684,259.92711354309165,893.0727111370895,261.995,930.0000000000001,266.86L930.0000000000001,303L45.359375,303Z" fill-opacity="0.8" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 0.8;"></path><path fill="none" stroke="#a890d3" d="M45.359375,303C82.1857696310447,301.2625,155.83855889313415,300.0407831737346,192.66495352417886,296.05C229.59224238708944,292.0482831737346,303.4468201129106,275.0317168262654,340.3741089758212,271.03C377.2005036068659,267.0392168262654,450.85329286895535,277.11125,487.67968750000006,264.08C524.5060821310448,251.04874999999998,598.1588713931342,168.865,634.9852660241788,166.78C671.8116606552236,164.695,745.464449917313,234.90711354309167,782.2908445483578,247.4C819.2181334112684,259.92711354309165,893.0727111370895,261.995,930.0000000000001,266.86" stroke-width="0" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><circle cx="45.359375" cy="303" r="0" fill="#a890d3" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="192.66495352417886" cy="296.05" r="0" fill="#a890d3" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="340.3741089758212" cy="271.03" r="0" fill="#a890d3" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="487.67968750000006" cy="264.08" r="0" fill="#a890d3" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="634.9852660241788" cy="166.78" r="0" fill="#a890d3" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="782.2908445483578" cy="247.4" r="0" fill="#a890d3" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="930.0000000000001" cy="266.86" r="0" fill="#a890d3" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle></svg><div class="morris-hover morris-default-style" style="left: 0px; top: 177px; display: none;"><div class="morris-hover-row-label">2011</div><div class="morris-hover-point" style="color: #689bc3">
  iphone:
  10
</div><div class="morris-hover-point" style="color: #a2b3bf">
  ipad:
  0
</div><div class="morris-hover-point" style="color: #64b764">
  itouch:
  0
</div></div></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-3 col-md-6 col-sm-12 text-center">
                <div class="card tasks_report">
                    <div class="body">
                        <div style="display:inline;width:90px;height:90px;"><canvas width="90" height="90"></canvas><input type="text" class="knob dial1" value="66" data-width="90" data-height="90" data-thickness="0.1" data-fgcolor="#666" readonly="readonly" style="width: 49px; height: 30px; position: absolute; vertical-align: middle; margin-top: 30px; margin-left: -69px; border: 0px; background: none; font: bold 18px Arial; text-align: center; color: rgb(102, 102, 102); padding: 0px; appearance: none;"></div>                        
                        <h6 class="m-t-20">Satisfaction Rate</h6>
                        <p class="displayblock m-b-0">47% Average <i class="zmdi zmdi-trending-up"></i></p>                        
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 text-center">
                <div class="card tasks_report">
                    <div class="body">
                        <div style="display:inline;width:90px;height:90px;"><canvas width="90" height="90"></canvas><input type="text" class="knob dial2" value="26" data-width="90" data-height="90" data-thickness="0.1" data-fgcolor="#7b69ec" readonly="readonly" style="width: 49px; height: 30px; position: absolute; vertical-align: middle; margin-top: 30px; margin-left: -69px; border: 0px; background: none; font: bold 18px Arial; text-align: center; color: rgb(123, 105, 236); padding: 0px; appearance: none;"></div>
                        <h6 class="m-t-20">Project Panding</h6>
                        <p class="displayblock m-b-0">13% Average <i class="zmdi zmdi-trending-down"></i></p>
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 text-center">
                <div class="card tasks_report">
                    <div class="body">
                        <div style="display:inline;width:90px;height:90px;"><canvas width="90" height="90"></canvas><input type="text" class="knob dial3" value="76" data-width="90" data-height="90" data-thickness="0.1" data-fgcolor="#f9bd53" readonly="readonly" style="width: 49px; height: 30px; position: absolute; vertical-align: middle; margin-top: 30px; margin-left: -69px; border: 0px; background: none; font: bold 18px Arial; text-align: center; color: rgb(249, 189, 83); padding: 0px; appearance: none;"></div>
                        <h6 class="m-t-20">Productivity Goal</h6>
                        <p class="displayblock m-b-0">75% Average <i class="zmdi zmdi-trending-up"></i></p>
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 text-center">
                <div class="card tasks_report">
                    <div class="body">
                        <div style="display:inline;width:90px;height:90px;"><canvas width="90" height="90"></canvas><input type="text" class="knob dial4" value="88" data-width="90" data-height="90" data-thickness="0.1" data-fgcolor="#00adef" readonly="readonly" style="width: 49px; height: 30px; position: absolute; vertical-align: middle; margin-top: 30px; margin-left: -69px; border: 0px; background: none; font: bold 18px Arial; text-align: center; color: rgb(0, 173, 239); padding: 0px; appearance: none;"></div>
                        <h6 class="m-t-20">Total Revenue</h6>
                        <p class="displayblock m-b-0">54% Average <i class="zmdi zmdi-trending-up"></i></p>
                        
                    </div>
                </div>
            </div>            
        </div>
        
                       <!-- <div class="row clearfix">
                            <div class="col-lg-4 col-sm-6">
                                <div class="progress-container m-b-20">
                                    <span class="progress-badge">visitor from america</span>
                                    <div class="progress">
                                        <div class="progress-bar l-turquoise" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                            <span class="progress-value">86%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="progress-container m-b-20">
                                    <span class="progress-badge">visitor from Canada</span>
                                    <div class="progress">
                                        <div class="progress-bar l-coral" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                            <span class="progress-value">86%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="progress-container m-b-20">
                                    <span class="progress-badge">visitor from asia</span>
                                    <div class="progress">
                                        <div class="progress-bar l-blue" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                            <span class="progress-value">86%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="progress-container m-b-20">
                                    <span class="progress-badge">visitor from america</span>
                                    <div class="progress">
                                        <div class="progress-bar l-salmon" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                            <span class="progress-value">86%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="progress-container m-b-20">
                                    <span class="progress-badge">visitor from Canada</span>
                                    <div class="progress">
                                        <div class="progress-bar l-parpl" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                            <span class="progress-value">86%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="progress-container m-b-20">
                                    <span class="progress-badge">visitor from asia</span>
                                    <div class="progress">
                                        <div class="progress-bar l-amber" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                                            <span class="progress-value">86%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
            
        </div>          
    </div>
</section>
<!-- Jquery Core Js --> 
<script src="js/twk-main.js" charset="UTF-8" crossorigin="*"></script><script src="js/twk-vendor.js" charset="UTF-8" crossorigin="*"></script><script src="js/twk-chunk-vendors.js" charset="UTF-8" crossorigin="*"></script><script src="js/twk-chunk-common.js" charset="UTF-8" crossorigin="*"></script><script src="js/twk-runtime.js" charset="UTF-8" crossorigin="*"></script><script src="js/twk-app.js" charset="UTF-8" crossorigin="*"></script><script async="" src="js/default" charset="UTF-8" crossorigin="*"></script><script src="js/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js ( jquery.v3.2.1, Bootstrap4 js) --> 
<script src="js/vendorscripts.bundle.js"></script> <!-- slimscroll, waves Scripts Plugin Js -->

<script src="js/morrisscripts.bundle.js"></script><!-- Morris Plugin Js -->
<script src="js/jvectormap.bundle.js"></script> <!-- JVectorMap Plugin Js -->
<script src="js/knob.bundle.js"></script> <!-- Jquery Knob Plugin Js -->
<script src="js/sparkline.bundle.js."></script> <!-- Sparkline Plugin Js -->

<script src="js/mainscripts.bundle.js"></script>
<script src="js/index.js"></script>

<div class="jvectormap-tip"></div><script async="" charset="UTF-8" src="js/en.js"></script><div id="ql4ka8c628v1f7tcld3d" style="display: block !important;">
    
</div></div></body></html>